package com.braindata.bankmanagement.service;

public interface Rbi {

	void createAccount();
    void displayAllDetails();
    void depositeMoney();
    void withdrawal();
    void balanceCheck();
}
